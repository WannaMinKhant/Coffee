﻿Imports AForge.Video.DirectShow
Imports BarcodeLib.BarcodeReader

Public Class Form1
    Private dispositives As FilterInfoCollection
    Private Fvideo As VideoCaptureDevice
    Private Wvideo As VideoCaptureDeviceForm
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dispositives = New FilterInfoCollection(FilterCategory.VideoInputDevice)
        For Each x As FilterInfo In dispositives
            ComboBox1.Items.Add(x.Name)
        Next
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Timer1.Enabled = True
        Timer1.Start()
        Fvideo = New VideoCaptureDevice(dispositives(ComboBox1.SelectedIndex).MonikerString)
        VideoSourcePlayer1.VideoSource = Fvideo
        VideoSourcePlayer1.Start()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Stop()
        VideoSourcePlayer1.Stop()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        VideoSourcePlayer1.Stop()
        Application.Exit()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If VideoSourcePlayer1.GetCurrentVideoFrame() Is Nothing Then
            Else

                Dim img As Bitmap
                img = (VideoSourcePlayer1.GetCurrentVideoFrame().Clone())
                'MsgBox(img.PixelFormat)
                Dim result() As String = BarcodeReader.read(img, BarcodeReader.QRCODE)

                img.Dispose()
                If result.Count > 0 Then
                    ListBox1.Items.Add(result(0))
                End If
            End If
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ListBox1.Items.Clear()
    End Sub
End Class
